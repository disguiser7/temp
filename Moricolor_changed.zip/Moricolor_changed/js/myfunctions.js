//获取当前文件所在的url
var getThemeUrl = function(){
    var url = $("script").last().attr("src");
    var pos = url.length;
    for(var count = 0; count != 2; --pos){
        if(url[pos] == '/') ++count;
    }
    url = url.slice(0,pos+1);
    return url;
}

// 调用zoom.js
var setupContents = function () {
    $(".post-content img:not(article .link-box img, img[no-zoom])").each(function() {
        $(this).attr('data-action', 'zoom');
        if($(this).next().is('br')){
            $(this).next().remove();
        }
    });
};

//设置图片的右下标信息
var setImageTitle = function(){
    var img = new Image();
    img.src = $("img").attr("src");
    if(img.naturalWidth == undefined || img.naturalHeight == undefined){
        $("img").after("<span class=\"imgsubscript\">"+$("img").attr("alt")+"|"+"0x0"+"</span>"+"</br>");
    }
    else{
        $("img").after("<span class=\"imgsubscript\">"+$("img").attr("alt")+"|"+img.naturalWidth+"x"+img.naturalHeight+"</span>"+"</br>");
    }
}

//默认显示文章目录,可以在post.php中修改
var show_tor = function(){
    $("#postTor").css('display','inline-block');
}


var goTop = function(){
   document.write("<div class=\"goTop\"><a href=\"#top\"><img src=\""+getThemeUrl()+"/image/icon/top.svg\"></img></a></div>");
}

var navBar = function(){

}

var dectectScroll = function(){
    var dis = $(document).scrollTop();
    alert(dis);
}

setupContents();
setImageTitle();
//show_tor();
goTop();

//dectectScroll();

